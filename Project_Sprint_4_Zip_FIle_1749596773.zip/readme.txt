You Can View My Tableau Project Here
https://public.tableau.com/app/profile/cash.najar/viz/Sprint4Workbook_17495964143080/AvgProfitvsAvgReturnRate#1